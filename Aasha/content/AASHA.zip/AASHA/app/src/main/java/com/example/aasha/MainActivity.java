package com.example.aasha;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView mWebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWebview  = new WebView(this);
        final WebView webview = (WebView) findViewById(R.id.webview);
        mWebview.getSettings().setJavaScriptEnabled(true); // enable javascript
        final Activity activity = this;
        try{
            mWebview.loadUrl("http://aasha.laxmiwafersncones.com");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        setContentView(mWebview );
        final boolean[] loadingFinished = {true};
        final boolean[] redirect = {false};
        mWebview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView  view, String  url){
                return true;
            }
            // here you execute an action when the URL you want is about to load
            @Override
            public void onLoadResource(WebView  view, String  url){

            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description+failingUrl, Toast.LENGTH_SHORT).show();
            }
            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                // Redirect to deprecated method, so you can use it in all SDK versions
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }


            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!loadingFinished[0]) {
                    redirect[0] = true;
                }

                loadingFinished[0] = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    mWebview.loadUrl(request.getUrl().toString());
                }
                return true;
            }

            @Override
            public void onPageStarted(
                    WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                loadingFinished[0] = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!redirect[0]) {
                    loadingFinished[0] = true;
                } else {
                    redirect[0] = false;
                }
            }


        });

    }

    @Override
    public void onBackPressed() {
        if(mWebview.canGoBack()){
            mWebview.goBack();
        }else{
            super.onBackPressed();
        }
    }

}
